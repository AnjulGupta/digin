from flask import render_template
from sqlalchemy import and_
from flask import url_for, redirect, request, make_response,flash
# Importing Session Object to use Sessions
from flask import session
from app.models import Customer, Restadmin, Items, Orders, Diginadmin
from app import app, db



@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')


# customerregister.html
@app.route('/register')
def register():
	return render_template('userregister.html')

# customerregisterNext.py
@app.route('/registerNext', methods = ['GET','POST'])
def registerNext():

	customer = Customer(cname=request.form["cname"], cmail=request.form["cmail"], cmobile=request.form["cmobile"], caddress=request.form["caddress"], cpassword=request.form['cpassword'])
	
	db.session.add(customer)
	db.session.commit()

	return redirect(url_for('login'))
	
# customerlogin.html
@app.route('/login')
def login():
	return render_template('userlogin.html')

	
# customerloginNext.html
@app.route('/loginNext',methods=['GET','POST'])
def loginNext():
	# To find out the method of request, use 'request.method'

	# if request.method == "GET":
	# 	cmail = request.args.get("cmail")
	# 	cpassword = request.args.get("cpassword")
	
	# elif request.method == "POST":
	# 	cmail = request.form['cmail']
	# 	cpassword = request.form['cpassword']

		
		# Can perform some password validation here!
		# customer  = Customer.query.filter(and_(Customer.cmail == cmail, Customer.cpassword == cpassword)).first()


		# if customer :
			# session['cmail'] = request.form['cmail']
			# return render_template('userhome.html',cusname=customer.cname,restadmin = Restadmin.query.all())
			return render_template('userhome.html',restadmin = Restadmin.query.all())
			
		# return "Login failed ...!"


		


# customerlogout.html
@app.route('/logout')
def logout():
	# Remove the session variable if present
	session.pop('cmail',None)
	return redirect(url_for('index'))



@app.route('/restmenu', methods = ['GET','POST'])
def restmenu():
	if request.method == "GET":
		restid = request.args.get("restid")
	
	elif request.method == "POST":
		restid = request.form['restid']

	items = Items.query.filter(Items.rid == restid).all()
	# restad = Restadmin.query.filter(Restadmin.rid == restid).first()
	# return(items.iname)
	return render_template('restmenu.html', restadmin=items)
		


